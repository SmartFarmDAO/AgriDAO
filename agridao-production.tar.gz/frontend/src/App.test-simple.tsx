import React from 'react';

const SimpleApp: React.FC = () => {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>AgriDAO - Test</h1>
      <p>If you see this, React is working!</p>
    </div>
  );
};

export default SimpleApp;
