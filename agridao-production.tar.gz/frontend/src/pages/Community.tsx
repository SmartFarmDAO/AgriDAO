import Community from '../components/Community';

export default function CommunityPage() {
  return <Community />;
}
