import Blockchain from '../components/Blockchain';

export default function BlockchainPage() {
  return <Blockchain />;
}
