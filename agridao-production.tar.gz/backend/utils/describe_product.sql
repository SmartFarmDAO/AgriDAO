\d product
