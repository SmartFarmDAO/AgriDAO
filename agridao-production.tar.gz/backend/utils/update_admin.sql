UPDATE "user" SET role = 'ADMIN' WHERE email = 'riajurpbl@gmail.com';
SELECT id, email, name, role FROM "user" WHERE email = 'riajurpbl@gmail.com';
